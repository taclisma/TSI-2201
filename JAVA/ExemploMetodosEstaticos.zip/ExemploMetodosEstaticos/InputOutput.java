import javax.swing.*;

public class InputOutput {
    
    public static String leDados(String mensagem){
        String s = JOptionPane.showInputDialog(null, mensagem);
        return s;
    }
    
    public static void exibeDados(String mensagem){
        JOptionPane.showMessageDialog(null,mensagem);
    }
    
}