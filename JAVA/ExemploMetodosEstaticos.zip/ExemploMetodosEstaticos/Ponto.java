
/**
 * Write a description of class Ponto here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ponto
{
    // instance variables - replace the example below with your own
    private int x;
    private int y;

    /**
     * Constructor for objects of class Ponto
     */
    public Ponto(int x, int y)
    {
        // initialise instance variables
        this.x = x;
        this.y = y;
    }

    public String informaCoordenadas(){
        return ("x = "+ x + " e y = "+ y);
    }
}
