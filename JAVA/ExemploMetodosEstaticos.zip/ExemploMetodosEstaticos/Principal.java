public class Principal{ 
    
public static void main(String [] args) {
     
     String s1 = InputOutput.leDados("Informe a coordenada x");
     String s2 = InputOutput.leDados("Informe a coordenada y");
     Ponto p1 = new Ponto (Integer.parseInt(s1),Integer.parseInt(s2)); 
     
     InputOutput.exibeDados(p1.informaCoordenadas());
    }
}