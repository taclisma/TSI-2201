drop table cliente
drop table produto
drop table pedido
drop table pedido_produto

--drop das sequences é necessario igual 
drop sequence s_cliente;
drop sequence s_produto;
drop sequence s_pedido;