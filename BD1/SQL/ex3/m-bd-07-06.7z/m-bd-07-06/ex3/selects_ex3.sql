--12. Apresentar o valor médio dos pedidos(de todos).
select avg(sum(pp.valor_venda*pp.quantidade)) 
    from pedido_produto pp
    group by pp.id_pedido;

--13. o nome do cliente e a quantidade de pedidos deste cliente. (Se o cliente não fez pedidos ele não precisa aparecer no resultado)
select cliente.nome, count(pedido.id_pedido)
    from cliente inner join pedido
    on cliente.id_cliente = pedido.id_cliente group by cliente.nome;


--15. Apresentar o código do pedido, nome do cliente e o total a ser pago para cada pedido. Ordenar pelo código do pedido.
select pp.id_pedido, c.nome, sum(pp.quantidade*pp.valor_venda)
    from pedido_produto pp inner join pedido p
    on pp.id_pedido = p.id_pedido
    inner join cliente c
    on p.id_cliente = c.id_cliente
    group by pp.id_pedido, c.nome, c.id_cliente
    order by pp.id_pedido;

--16. Apresentar o id dos pedidos somente para os pedidos com mais de 2(mudado para 1) produtos diferentes.
select id_pedido 
    from pedido_produto
    group by id_pedido
    having count(id_produto) > 1;